import java.awt.geom.Point2D;

import javax.swing.JPanel;

import javafx.util.Pair;

@SuppressWarnings("serial")
public class dot extends JPanel {

    static int startingX = 150;
    static int startingY = 450;

    private int x;
    private int y;

    private brain b;

    private boolean isDead;
    private boolean reachedGoal;
    private boolean isBestDot;

    public dot() {

        // gives dot its starting properties
        this.x = startingX;
        this.y = startingY;
        this.isDead = false;
        this.reachedGoal = false;
        this.isBestDot = false;

        // creates the brain for the dot
        this.b = new brain();

    }

    // moves the dot by one "step"
    public void move() {

        if (this.b.getCurrentStep() < this.b.totalSteps) {
            Pair<Integer, Integer> next = this.b.nextStep();

            if (!this.isDead && !this.reachedGoal) {
                this.x += next.getKey();
                this.y += next.getValue();
                this.update();
            }
        } else {
            this.isDead = true;
            this.reachedGoal = true;
        }

    }

    // checks whether a dot has hit a wall, goal, or one of the gates
    public void update() {

        int posX = this.x;
        int posY = this.y;

        if (!this.isDead && !this.reachedGoal) {

            if (posX < 2 || posY < 2 || posX > 308 || posY > 488) { //if near the edges of the window then kill it
                this.isDead = true;

            } else if (Point2D.distance(posX, posY, 150, 50) < 1) { //if reached goal
                this.reachedGoal = true;

            } else if (posX > 0 && posX < 200 && posY > 397 && posY < 403) { //if hit obstacle first line right
                this.isDead = true;

            } else if (posX > 250 && posX < 400 && posY > 397 && posY < 403) { //if hit obstacle first line left
                this.isDead = true;

            } else if (posX > 100 && posX < 350 && posY > 297 && posY < 303) { //if hit obstacle second line right
                this.isDead = true;

            } else if (posX > 0 && posX < 50 && posY > 297 && posY < 303) { //if hit obstacle second line left
                this.isDead = true;

            } else if (posX > 0 && posX < 200 && posY > 197 && posY < 203) { //if hit obstacle third line right
                this.isDead = true;

            } else if (posX > 250 && posX < 350 && posY > 197 && posY < 203) { //if hit obstacle third line left
                this.isDead = true;

            } else if (posX > 100 && posX < 350 && posY > 97 && posY < 103) { //if hit obstacle fourth line right
                this.isDead = true;

            } else if (posX > 0 && posX < 50 && posY > 97 && posY < 103) { //if hit obstacle fourth line left
                this.isDead = true;

            }

        }

    }

    // ------------ getter methods --------------------
    public int xPos() {
        return this.x;
    }

    public int yPos() {
        return this.y;
    }

    public boolean getIsDead() {
        return this.isDead;
    }

    public boolean getReachedGoal() {
        return this.reachedGoal;
    }

    public brain getDotsBrain() {

        return this.b;
    }

    public boolean isBestDot() {
        return this.isBestDot;
    }

    // ----------- setter methods -------------------
    public void resetDot() {
        this.x = startingX;
        this.y = startingY;
        this.b.resetCurrentSteps();
        this.isDead = false;
        this.reachedGoal = false;
    }

    public void setBestDot() {
        this.isBestDot = true;
    }

    public void unsetBestDot() {
        this.isBestDot = false;
    }

}
