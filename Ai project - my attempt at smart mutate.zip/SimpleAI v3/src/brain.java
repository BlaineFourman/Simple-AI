import java.util.LinkedList;
import java.util.Random;

import javafx.util.Pair;

public class brain {

    static final int totalSteps = 5000;
    private int currentStep;

    LinkedList<Integer> xMovements;
    LinkedList<Integer> yMovements;

    public brain() {

        // Intialize properties
        this.xMovements = new LinkedList<>();
        this.yMovements = new LinkedList<>();
        this.currentStep = 0;

        // Adds movements to each vector
        this.randomize(this.xMovements);
        this.randomize(this.yMovements);

    }

    // Gives the next step of the brain
    public Pair<Integer, Integer> nextStep() {

        // gets next element and increases current step
        int nextX = this.xMovements.get(this.currentStep);
        int nextY = this.yMovements.get(this.currentStep);
        this.currentStep++;

        Pair<Integer, Integer> r = new Pair<>(nextX, nextY);
        return r;

    }

    // sets each value of the vector v to a small value (-2 to 2)
    public void randomize(LinkedList<Integer> v) {

        for (int i = 0; i < totalSteps; i++) {
            int randomNum = (new Random().nextInt(5)) - 2;
            v.add(randomNum);
        }

    }

    // ------------- getter methods --------------
    public int getCurrentStep() {
        return this.currentStep;
    }

    public LinkedList<Integer> getXVector() {
        return this.xMovements;
    }

    public LinkedList<Integer> getYVector() {
        return this.yMovements;
    }

    // ------------- mutator methods-------------
    public void mutateBrain() {
        Random rand = new Random();

        for (int i = 0; i < totalSteps; i++) {
            int randNum = rand.nextInt(100);
            if (randNum == 0) { // runs 1% of the time

                this.xMovements.remove(i);
                this.yMovements.remove(i);

                int randX = (rand.nextInt(5)) - 2;
                int randY = (rand.nextInt(5)) - 2;

                this.xMovements.add(i, randX);
                this.yMovements.add(i, randY);

            }
        }

    }

    public void resetCurrentSteps() {
        this.currentStep = 0;
    }

}
