import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class population {

    static int populationSize = 20;

    private int currentGen;
    private List<dot> dots;

    public population() {

        // intializes properties
        this.currentGen = 1;
        this.dots = new Vector<>();

        // adds new dots to the population
        for (int i = 0; i < populationSize; i++) {
            this.dots.add(new dot());
        }

    }

    // Checks to see if all of the dots have finished
    public boolean allDone() {
        boolean r = true;

        for (dot singleDot : this.dots) {

            if (!(singleDot.getIsDead() || singleDot.getReachedGoal())) {
                if (singleDot.getDotsBrain()
                        .getCurrentStep() < brain.totalSteps) {
                    r = false;
                    break;
                }
            }

        }

        return r;
    }

    // gets the bestDot
    public dot findBestDot() {
        dot r = new dot();
        double bestDistance = 1000; // number is larger highest possible distance so it will be overwritten after first pass of the for each loop

        // goes through each dot and find the lowest distance
        for (dot singleDot : this.dots) {
            int finalX = singleDot.xPos();
            int finalY = singleDot.yPos();

            double distance = Math.hypot(finalX - gui.goalPosX,
                    finalY - gui.goalPosY);

            if (distance < bestDistance) {
                r = singleDot;
                distance = bestDistance;

            }
        }

        return r;
    }

    // mutates other dots to reflect the best dot
    public void mutateDots() {
        // make all dots the same as the best dot
        dot bestDot = this.findBestDot();

        LinkedList<Integer> bestX = bestDot.getDotsBrain().xMovements;
        LinkedList<Integer> bestY = bestDot.getDotsBrain().yMovements;

        for (int i = 0; i < populationSize; i++) {
            dot currentDot = this.dots.remove(i);

            currentDot.getDotsBrain().xMovements = new LinkedList<>(bestX);
            currentDot.getDotsBrain().yMovements = new LinkedList<>(bestY);

            this.dots.add(i, currentDot);
        }

        // mutate all dots other than the first
        for (int i = 1; i < populationSize; i++) {
            dot currentDot = this.dots.remove(i);
            currentDot.getDotsBrain().mutateBrain();
            this.dots.add(i, currentDot);
        }

        this.reset();

        // increment currentGen and run again
        this.currentGen++;

    }

    private void reset() {
        for (dot currentDot : this.dots) {
            currentDot.resetDot();

        }
    }

    // ----------- getter methods -----------
    public int getCurrentGen() {
        return this.currentGen;
    }

    public List<dot> getListOfDots() {
        return this.dots;
    }

    public int numberOfDotsToReachGoal() {
        int r = 0;

        for (dot currentDot : this.dots) {
            if (currentDot.getReachedGoal()) {
                r++;
            }
        }

        return r;
    }

}
