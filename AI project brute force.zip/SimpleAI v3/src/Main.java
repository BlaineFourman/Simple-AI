import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main extends JPanel {

    public static void main(String[] args) {

        // Creates window
        JFrame mainFrame = new JFrame();
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainFrame.setPreferredSize(new Dimension(300, 500));

        // Creates gui
        gui g = new gui();
        mainFrame.add(g);
        mainFrame.pack();
        mainFrame.setVisible(true);

        // starts the ai
        g.start();

        population pop = g.getPopulation();
        // continues to run until 50% of dots reach the goal
        int numReachedGoal = (pop.populationSize) / 2;

        while (numReachedGoal > pop.numberOfDotsToReachGoal()) {

            pop.mutateDots();

            g.start();
        }

    }

}
