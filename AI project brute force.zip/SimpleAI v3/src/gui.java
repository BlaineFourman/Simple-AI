import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class gui extends JPanel {

    private population pop;
    static int goalPosX = 150;
    static int goalPosY = 50;

    public gui() {

        // Initialize properties
        this.pop = new population();

    }

    // Starts the dots
    public void start() {

        while (!this.pop.allDone()) {

            for (dot singleDot : this.pop.getListOfDots()) {
                singleDot.move();
                this.repaint();

            }

            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
            }

        }

    }

    // Paints everything to the jpanel
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponents(g);
        g.clearRect(0, 0, this.getWidth(), this.getHeight());

        // Draws all of the obstacles
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(6));

        // bottom gate
        g2d.drawLine(0, 400, 200, 400);
        g2d.drawLine(250, 400, 300, 400);

        // second to last gate
        g2d.drawLine(300, 300, 100, 300);
        g2d.drawLine(0, 300, 50, 300);

        // second to top gate
        g2d.drawLine(0, 200, 200, 200);
        g2d.drawLine(250, 200, 300, 200);

        // top gate
        g2d.drawLine(300, 100, 100, 100);
        g2d.drawLine(0, 100, 50, 100);

        // Goal
        g2d.setColor(Color.RED);
        g2d.fillOval(150 - 3, 50 - 3, 6, 6);

        // Shows current gen
        g2d.setColor(Color.BLACK);
        g2d.drawString("Current gen: " + this.pop.getCurrentGen(), 210, 20);

        // Draw dot
        g2d.setColor(Color.magenta);
        for (dot singleDot : this.pop.getListOfDots()) {

            g2d.fillOval(singleDot.xPos() - 2, singleDot.yPos() - 2, 4, 4);

        }

    }

    // --------- getter methods --------------
    public population getPopulation() {
        return this.pop;
    }

}
